//Hoistiong
//Hoisting is a javascript mechanism where function declarations are moved to the top of thir dcope before code execution


//note function execution is move to top step by step 
let x =34;
let y=35;
let result = add(x,y);
console.log(result);
function add(x,y){
    return x>y;
}