const numbers = [1,-2,6,-25,6];
const result = numbers.filter((number) => number > 0);
console.log(result)