// Map Array methods
// Map , Filter & Reduce 
// map()  Example 


const numbers = [1,2,3,4,6,5,5,65,565,5];
const result = numbers.map((number) => number * number);
console.log(result)