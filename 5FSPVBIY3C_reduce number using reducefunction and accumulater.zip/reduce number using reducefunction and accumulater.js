const number = [1,2,4,5];
const result = number.reduce((acc, number) => acc + number );
console.log(result)