//Global scope 
let x = 34;
function foo(){
    if (x>18){
        console.log(x);
    }
}
foo();