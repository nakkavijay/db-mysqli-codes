INSERT INTO
  player(name, age, score)
VALUES
  ("dfs", 344, 5354),
  ("dfs", 64, 666),
  ("dkfsadklf", 5454, 5454)