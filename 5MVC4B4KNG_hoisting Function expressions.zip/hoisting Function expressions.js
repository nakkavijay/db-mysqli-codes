// Hoisting 
// function Expresion
//function Expresion and arrow function in javascript are not hoisted
let x = 34;
let y = 54;
let result = add(x,y);
console.log(result);
let add = function(x,y){
    return x>y;
}

// refference error came  cannot access add before initilize

//  function add(x,y){
//    return x>y;
//}  ans will false