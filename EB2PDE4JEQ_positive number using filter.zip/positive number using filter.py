# filter 
def is_positive_number(num):
    return num> 0
list_a = [1,-2,4,-5]
positive_nums =  filter(is_positive_number,list_a)
print(list(positive_nums))