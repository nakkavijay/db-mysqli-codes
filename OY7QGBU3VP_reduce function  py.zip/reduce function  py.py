from functools import reduce 
def sum_of_num (a,b):
    return a + b

list_a = [1,2,3,4];
sum_of_list = reduce(sum_of_num,list_a)
print(sum_of_list)