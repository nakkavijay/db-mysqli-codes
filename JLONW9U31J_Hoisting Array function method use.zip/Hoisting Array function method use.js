//Hoisting Arrow function

let x = 34;
let y = 54;
let result = add(x,y);
console.log(result);
let add = (x,y) =>{
    return x>y;
}
// refference error cannot access before inilizee